export const NavbarLinks = [
  {
    title: "Home",
    path: "/",
  },
  {
    title: "Services",   
  },
  {
    title: "About Us",
    path: "/about",
  },
  {
    title: "Contact Us",
    path: "/contact",
  },
];
